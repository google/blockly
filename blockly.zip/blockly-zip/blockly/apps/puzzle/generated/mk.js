// This file was automatically generated from common.soy.
// Please don't edit this file by hand.

if (typeof apps == 'undefined') { var apps = {}; }


apps.messages = function(opt_data, opt_ignored, opt_ijData) {
  return '<div style="display: none"><span id="subtitle">визуелна околина за програмирање</span><span id="blocklyMessage">Блокли</span><span id="codeTooltip">Погл. создадениот JavaScript-код. </span><span id="linkTooltip">Зачувај и стави врска до блокчињата.</span><span id="runTooltip">Пушти го програмот определен од блокчињата во \\nработниот простор. </span><span id="runProgram">Пушти го програмот</span><span id="resetProgram">Одново</span><span id="dialogOk">ОК</span><span id="dialogCancel">Откажи</span><span id="catLogic">Логика</span><span id="catLoops">Јамки</span><span id="catMath">Математика</span><span id="catText">Текст</span><span id="catLists">Списоци</span><span id="catColour">Боја</span><span id="catVariables">Променливи</span><span id="catProcedures">Процедури</span><span id="httpRequestError">Се појави проблем во барањето.</span><span id="linkAlert">Споделете ги вашите блокчиња со оваа врска:\n\n%1</span><span id="hashError">„%1“ не одговара на ниеден зачуван програм.</span><span id="xmlError">Не можев да ја вчитам зачуваната податотека. Да не сте ја создале со друга верзија на Blockly?</span><span id="listVariable">список</span><span id="textVariable">текст</span></div>';
};


apps.dialog = function(opt_data, opt_ignored, opt_ijData) {
  return '<div id="dialogShadow" class="dialogAnimate"></div><div id="dialogBorder"></div><div id="dialog"></div>';
};


apps.codeDialog = function(opt_data, opt_ignored, opt_ijData) {
  return '<div id="dialogCode" class="dialogHiddenContent"><pre id="containerCode"></pre>' + apps.ok(null, null, opt_ijData) + '</div>';
};


apps.storageDialog = function(opt_data, opt_ignored, opt_ijData) {
  return '<div id="dialogStorage" class="dialogHiddenContent"><div id="containerStorage"></div>' + apps.ok(null, null, opt_ijData) + '</div>';
};


apps.ok = function(opt_data, opt_ignored, opt_ijData) {
  return '<div class="farSide" style="padding: 1ex 3ex 0"><button class="secondary" onclick="BlocklyApps.hideDialog(true)">ОК</button></div>';
};

;
// This file was automatically generated from template.soy.
// Please don't edit this file by hand.

if (typeof puzzlepage == 'undefined') { var puzzlepage = {}; }


puzzlepage.messages = function(opt_data, opt_ignored, opt_ijData) {
  return '<div style="display: none"><span id="Puzzle_country1">Австралија</span><span id="Puzzle_country1Flag">flag_au.png</span><span id="Puzzle_country1FlagHeight">50</span><span id="Puzzle_country1FlagWidth">100</span><span id="Puzzle_country1Language">англиски</span><span id="Puzzle_country1City1">Мелбурн</span><span id="Puzzle_country1City2">Сиднеј</span><span id="Puzzle_country1HelpUrl">http://mk.wikipedia.org/wiki/Австралија</span><span id="Puzzle_country2">Германија</span><span id="Puzzle_country2Flag">flag_de.png</span><span id="Puzzle_country2FlagHeight">60</span><span id="Puzzle_country2FlagWidth">100</span><span id="Puzzle_country2Language">германски</span><span id="Puzzle_country2City1">Берлин</span><span id="Puzzle_country2City2">Минхен</span><span id="Puzzle_country2HelpUrl">http://mk.wikipedia.org/wiki/Германија</span><span id="Puzzle_country3">Кина</span><span id="Puzzle_country3Flag">flag_cn.png</span><span id="Puzzle_country3FlagHeight">66</span><span id="Puzzle_country3FlagWidth">100</span><span id="Puzzle_country3Language">кинески</span><span id="Puzzle_country3City1">Пекинг</span><span id="Puzzle_country3City2">Шангај</span><span id="Puzzle_country3HelpUrl">http://mk.wikipedia.org/wiki/Кина</span><span id="Puzzle_country4">Бразил</span><span id="Puzzle_country4Flag">flag_br.png</span><span id="Puzzle_country4FlagHeight">70</span><span id="Puzzle_country4FlagWidth">100</span><span id="Puzzle_country4Language">португалски</span><span id="Puzzle_country4City1">Рио де Жанеиро</span><span id="Puzzle_country4City2">Сао Паоло</span><span id="Puzzle_country4HelpUrl">http://mk.wikipedia.org/wiki/Бразил</span><span id="Puzzle_flag">знаме:</span><span id="Puzzle_language">јазик:</span><span id="Puzzle_languageChoose">одберете...</span><span id="Puzzle_cities">градови:</span><span id="Puzzle_error0">Совршено!\nСите %1 блокови се точни.</span><span id="Puzzle_error1">За малку! Само еден блок е грешен.</span><span id="Puzzle_error2">Има %1 грешни блокови.</span><span id="Puzzle_tryAgain">Потцртаниот блок не е исправен.\nОбидувајте се и понатаму.</span></div>';
};


puzzlepage.start = function(opt_data, opt_ignored, opt_ijData) {
  return puzzlepage.messages(null, null, opt_ijData) + '<table id="header" width="100%"><tr><td valign="bottom"><h1><span id="title"><a href="../index.html">Блокли</a> : Сложувалка</span></h1></td><td class="farSide"><select id="languageMenu"></select>&nbsp; &nbsp;<button id="helpButton">Помош</button>&nbsp; &nbsp;<button id="checkButton" class="primary">Провери одговори</button></td></tr></table><script type="text/javascript" src="../../blockly_compressed.js"><\/script><script type="text/javascript" src="../../' + soy.$$escapeHtml(opt_ijData.langSrc) + '"><\/script><script type="text/javascript" src="blocks.js"><\/script><div id="blockly"></div>' + apps.dialog(null, null, opt_ijData) + '<div id="help" class="dialogHiddenContent"><div style="padding-bottom: 0.7ex">За секоја земја (зелено), прикачете го знамето, изберете кој јазик го зборува и наредете ги градовите.</div><iframe style="height: 200px; width: 100%; border: none;" src="readonly.html?lang=' + soy.$$escapeHtml(opt_ijData.lang) + '&xml=%3Cblock+type%3D%22country%22+x%3D%225%22+y%3D%225%22%3E%3Cmutation+country%3D%221%22%3E%3C%2Fmutation%3E%3Ctitle+name%3D%22LANG%22%3E1%3C%2Ftitle%3E%3Cvalue+name%3D%22FLAG%22%3E%3Cblock+type%3D%22flag%22%3E%3Cmutation+country%3D%221%22%3E%3C%2Fmutation%3E%3C%2Fblock%3E%3C%2Fvalue%3E%3Cstatement+name%3D%22CITIES%22%3E%3Cblock+type%3D%22city%22%3E%3Cmutation+country%3D%221%22+city%3D%222%22%3E%3C%2Fmutation%3E%3Cnext%3E%3Cblock+type%3D%22city%22%3E%3Cmutation+country%3D%221%22+city%3D%221%22%3E%3C%2Fmutation%3E%3C%2Fblock%3E%3C%2Fnext%3E%3C%2Fblock%3E%3C%2Fstatement%3E%3C%2Fblock%3E"></iframe>' + apps.ok(null, null, opt_ijData) + '</div><div id="answers" class="dialogHiddenContent"><div id="answerMessage"></div><div id="graph"><div id="graphValue"></div></div>' + apps.ok(null, null, opt_ijData) + '</div>';
};


puzzlepage.readonly = function(opt_data, opt_ignored, opt_ijData) {
  return puzzlepage.messages(null, null, opt_ijData) + '<script type="text/javascript" src="../../blockly_compressed.js"><\/script><script type="text/javascript" src="../../' + soy.$$escapeHtml(opt_ijData.langSrc) + '"><\/script><script type="text/javascript" src="blocks.js"><\/script><div id="blockly"></div>';
};
